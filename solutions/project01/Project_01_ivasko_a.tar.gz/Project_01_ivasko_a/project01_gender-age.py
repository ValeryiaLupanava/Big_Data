#!/opt/anaconda/envs/bd9/bin/python

#base
import os, sys
import datetime
import numpy as np
import pandas as pd
import re
import json
import pickle
#preprocess
from sklearn.feature_extraction.text import TfidfVectorizer
#classifiers
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
#pipeline block
from sklearn.pipeline import Pipeline
from sklearn.pipeline import FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin


columns=['gender','age','uid','user_json']

df = pd.read_table(
    sys.stdin, 
    sep='\t', 
    header=None, 
    names=columns
)

def re_domain_for_scrap(url):
    result = re.match(r'(http[s]?://)+(www.)?([^/]*)', url)[0].replace('http://http','http')
    if result is not None: return result
    if result is None : return None

def load_user_json(user_jsons):
    return user_jsons.map(json.loads)  

def token_all_urls(url_lst):
    text=' '.join(url_lst)
    text = re.sub('[^а-яА-Яa-zA-Z]', ' ', text)
    text = re.sub('https', ' ', text)
    text = re.sub('http', ' ', text)
    text = re.sub('www', ' ', text)    
    return text.lower().split()

def fake_tokenizer(text):
    return text
    
class TextSelector(BaseEstimator, TransformerMixin):
    """
    Transformer to select a single column from the data frame to perform additional transformations on
    Use on text columns in the data
    """
    def __init__(self, key):
        self.key = key

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X[self.key]
    

df['user_json'] = load_user_json(df['user_json'])
df['url_list'] = df['user_json'].map(lambda x: [visit['url'] for visit in x['visits']])
df['domain'] = df['url_list'].map(lambda x: [re_domain_for_scrap(url) for url in x])
df['class'] = df.gender + ' ' + df.age

scrap_dict_headers_file = "./scrap_dict_headers.pickle"
scrap_dict_text_file = "./scrap_text_headers.pickle"
scrap_dict_headers = pickle.load(open(scrap_dict_headers_file, 'rb'))
scrap_dict_text = pickle.load(open(scrap_dict_text_file, 'rb'))

def apply_scrap_dict_text(urls, domain_dict=scrap_dict_text):
    result=[]
    for url in urls:
        try: result.append(' '.join(domain_dict[url]))
        except: pass
    return ' '.join(result).split()

def apply_scrap_dict_headers(urls, domain_dict=scrap_dict_headers):
    result=[]
    for url in urls:
        try: result.append(' '.join(domain_dict[url]))
        except: pass
    return ' '.join(result).split()

df['scrap_text'] = df.domain.map(set).map(apply_scrap_dict_text)
df['scrap_headers'] = df.domain.map(set).map(apply_scrap_dict_headers)

df['url_set'] = df.url_list.map(set)

super_rus_dict_file = "./super_rus_dict.pickle"
super_rus_dict = pickle.load(open(super_rus_dict_file, 'rb'))
super_corp_dict_file = "./super_corp_dict.pickle"
super_corp_dict = pickle.load(open(super_corp_dict_file, 'rb'))
total_corp_dict = super_corp_dict
total_corp_dict.update(super_rus_dict)

def total_nf_from_dict(text):
    result=[]
    for word in text:
        try: result.append(total_corp_dict[word])
        except: pass
    return result

df['tokenized'] = df.url_set.map(token_all_urls)
df['words'] = df.tokenized.map(total_nf_from_dict)

# scrap_text = Pipeline([
#                 ('selector', TextSelector(key='scrap_text')), 
#                 ('tfidf', TfidfVectorizer(tokenizer=fake_tokenizer, max_df=0.8, 
#                                       lowercase=False, binary=True, use_idf=False, min_df=10))
#             ])
# domain = Pipeline([
#                 ('selector', TextSelector(key='domain')),
#                 ('tfidf', TfidfVectorizer(tokenizer=fake_tokenizer, ngram_range=(1,1),
#                                       lowercase=False, binary=True, use_idf=False, min_df=10, max_df=0.5))
#             ])
# words = Pipeline([
#                 ('selector', TextSelector(key='words')),
#                 ('tfidf', TfidfVectorizer(tokenizer=fake_tokenizer, 
#                                       lowercase=False, binary=True, use_idf=False, min_df=10, max_df=0.5))
#             ])

# pipeline1 = Pipeline([
#     ('features', words),
#     ('clf', MultinomialNB(alpha=0.2))])
# pipeline2 = Pipeline([
#     ('features', scrap_text),
#     ('clf', LogisticRegression(max_iter=300, solver='saga'))])
# pipeline3 = Pipeline([
#     ('features', domain),
#     ('clf', MultinomialNB(alpha=0.2))])
# estimators = [('pipe1', pipeline1), ('pipe2', pipeline2), ('pipe3', pipeline3)] 

features = ['scrap_text', 'domain', 'words']
target = 'class'

X_test, y_test = df[features], df[target]

#0.401333333333
model_file = "./4_est_scrap_40_are_you_kidding_me_project01_model.pickle"
#39933333333
#model_file = "4_est_scrap_40_and_again_project01_model.pickle"
#398
#model_file = "4_est_scrap_40_try_again_project01_model.pickle"
#390
#model_file = "4_est_scrap_gimme_40_please_project01_model.pickle"
pipeline = pickle.load(open(model_file, 'rb'))

df['predict'] = pipeline.predict(X_test)
df['gender'] = df.predict.map(lambda x: str(x).split()[0])
df['age'] = df.predict.map(lambda x: str(x).split()[1])

predicts_prob = pipeline.predict_proba(X_test)
df['prob'] = pd.Series([max(predicts_prob[i]) for i in range(len(predicts_prob))])
proba_diff = pd.Series([(sorted(predicts_prob[i],reverse=True)[0]-sorted(predicts_prob[i],reverse=True)[1]) for i in range(len(predicts_prob))])
df['prob_diff'] = proba_diff

#df.loc[df.prob_diff<df['prob_diff'].median(), ['gender', 'age']] = '-'
df.loc[df.prob<df['prob'].median(), ['gender', 'age']] = '-'

output = df[['uid', 'gender', 'age']]
output.sort_values(by='uid',axis = 0, ascending = True, inplace = True)
sys.stdout.write(output.to_json(orient='records'))